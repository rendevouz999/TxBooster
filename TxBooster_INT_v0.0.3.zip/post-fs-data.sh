#!/system/bin/sh
# placeholder post-fs-data.sh
