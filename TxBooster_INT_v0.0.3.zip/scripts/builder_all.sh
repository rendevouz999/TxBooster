#!/bin/bash
# TxBooster_INT v0.0.3
# All-in-one Builder Git Bash Friendly
# Author: rendevouz999
# Repo: https://github.com/rendevouz999

# Gunakan folder saat ini sebagai root modul
MODULE_DIR="$(pwd)"
ZIP_NAME="TxBooster_INT_v0.0.3.zip"
CHANGELOG="change.log"

cd "$MODULE_DIR" || { echo "Error: Tidak bisa masuk folder $MODULE_DIR"; exit 1; }

# 1️⃣ Update change.log versi terbaru
DATE=$(date '+%Y-%m-%d')
echo "## [v0.0.3] – $DATE" > temp_changelog.log
echo "- Core tweak + self-learning engine dengan baseline V0.0.1" >> temp_changelog.log
echo "- Profiling jitter & delay (before/after tweak)" >> temp_changelog.log
echo "- Log management (auto-delete >3 hari)" >> temp_changelog.log
echo "- post-fs-data.sh service auto-start" >> temp_changelog.log
echo "- Struktur modul rapih & siap integrasi KsuWebUI" >> temp_changelog.log
echo "- Author & kontak lengkap" >> temp_changelog.log
echo "- Pending:" >> temp_changelog.log
echo "  - Dynamic Mode Switching" >> temp_changelog.log
echo "  - Smart Notification" >> temp_changelog.log
echo "  - Auto Switch Gaming/Streaming/Idle" >> temp_changelog.log
echo "" >> temp_changelog.log
cat $CHANGELOG >> temp_changelog.log
mv temp_changelog.log $CHANGELOG

# 2️⃣ Set permissions untuk script
echo "Setting executable permissions..."
chmod +x scripts/*.sh post-fs-data.sh

# 3️⃣ Create ZIP
echo "Creating ZIP..."
zip -r "../$ZIP_NAME" * -x "*.DS_Store"

echo "============================="
echo "ZIP berhasil dibuat: ../$ZIP_NAME"
echo "Silakan flash via Magisk Manager"
echo "============================="
