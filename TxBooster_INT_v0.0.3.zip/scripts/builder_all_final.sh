#!/bin/bash
# TxBooster_INT v0.0.3
# Final Builder with fallback 7-Zip + all scripts check
# Author: rendevouz999

MODULE_DIR="$(pwd)"
ZIP_NAME="TxBooster_INT_v0.0.3.zip"

echo "=============================="
echo "TxBooster_INT Final Builder"
echo "Folder root: $MODULE_DIR"
echo "=============================="

# --- Check required scripts ---
REQUIRED_SCRIPTS=(
    "scripts/profiling.sh"
    "scripts/txbooster_core.sh"
    "scripts/log_manager.sh"
    "scripts/helper.sh"
    "post-fs-data.sh"
    "ksuwebui/index.html"
    "ksuwebui/style.css"
    "ksuwebui/api.sh"
    "config/default.conf"
    "config/user_profile.conf"
)

for f in "${REQUIRED_SCRIPTS[@]}"; do
    if [ ! -f "$MODULE_DIR/$f" ]; then
        echo "Warning: $f not found, creating placeholder..."
        mkdir -p "$(dirname "$MODULE_DIR/$f")"
        touch "$MODULE_DIR/$f"
    fi
done

# --- Make scripts executable ---
[ -d "$MODULE_DIR/scripts" ] && chmod +x "$MODULE_DIR/scripts/"*.sh
chmod +x "$MODULE_DIR/post-fs-data.sh"

# --- Update change.log ---
CHANGELOG="$MODULE_DIR/change.log"
DATE=$(date '+%Y-%m-%d')
{
echo "## [v0.0.3] – $DATE"
echo "- Core tweak + self-learning engine (baseline V0.0.1)"
echo "- Profiling jitter & delay (before/after tweak)"
echo "- Log management (auto-delete >3 hari)"
echo "- post-fs-data.sh service auto-start"
echo "- KsuWebUI toggle integrated"
echo "- Notifications integrated"
echo "- Author & kontak lengkap"
echo "- Pending:"
echo "  - Dynamic Mode Switching"
echo "  - Smart Notification"
echo "  - Auto Switch Gaming/Streaming/Idle"
echo ""
cat "$CHANGELOG" 2>/dev/null
} > temp_changelog.log
mv temp_changelog.log "$CHANGELOG"

# --- Build ZIP ---
echo "Creating ZIP..."
if command -v zip &> /dev/null; then
    zip -r "../$ZIP_NAME" * -x "*.DS_Store"
elif [ -f "/c/Program Files/7-Zip/7z.exe" ]; then
    "/c/Program Files/7-Zip/7z.exe" a "../$ZIP_NAME" *
else
    echo "Error: zip command or 7-Zip CLI not found!"
    exit 1
fi

echo "=============================="
echo "ZIP built successfully: ../$ZIP_NAME"
echo "Flash via Magisk Manager"
echo "=============================="
