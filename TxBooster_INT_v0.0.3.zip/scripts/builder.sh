#!/bin/bash
# TxBooster_INT v0.0.3
# Script builder otomatis untuk ZIP modul Magisk
# Author: rendevouz999
# Repo: https://github.com/rendevouz999

MODULE_NAME="TxBooster_INT_v0.0.3"
ZIP_NAME="${MODULE_NAME}.zip"

# Pastikan berada di folder root modul
if [ ! -d "$MODULE_NAME" ]; then
  echo "Error: Folder $MODULE_NAME tidak ditemukan!"
  exit 1
fi

cd "$MODULE_NAME" || exit

echo "Setting executable permissions..."
chmod +x scripts/*.sh post-fs-data.sh

echo "Membuat ZIP modul..."
zip -r "../$ZIP_NAME" * -x "*.DS_Store"

echo "ZIP berhasil dibuat: ../$ZIP_NAME"
echo "Siap di-flash via Magisk Manager!"
