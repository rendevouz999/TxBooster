#!/bin/bash
# TxBooster_INT v0.0.3
# All-in-one Builder Windows / Git Bash friendly with 7-Zip fallback
# Author: rendevouz999
# Repo: https://github.com/rendevouz999

MODULE_DIR="$(pwd)"
ZIP_NAME="TxBooster_INT_v0.0.3.zip"
CHANGELOG="change.log"

echo "=============================="
echo "TxBooster_INT Builder (Git Bash/Windows)"
echo "Folder root modul: $MODULE_DIR"
echo "=============================="

# 1️⃣ Pastikan change.log ada
[ ! -f "$CHANGELOG" ] && touch "$CHANGELOG"

# 2️⃣ Pastikan post-fs-data.sh ada
if [ ! -f "$MODULE_DIR/post-fs-data.sh" ]; then
    echo "#!/system/bin/sh" > "$MODULE_DIR/post-fs-data.sh"
    echo "# placeholder post-fs-data.sh" >> "$MODULE_DIR/post-fs-data.sh"
fi

# 3️⃣ Update change.log versi terbaru
DATE=$(date '+%Y-%m-%d')
{
echo "## [v0.0.3] – $DATE"
echo "- Core tweak + self-learning engine dengan baseline V0.0.1"
echo "- Profiling jitter & delay (before/after tweak)"
echo "- Log management (auto-delete >3 hari)"
echo "- post-fs-data.sh service auto-start"
echo "- Struktur modul rapih & siap integrasi KsuWebUI"
echo "- Author & kontak lengkap"
echo "- Pending:"
echo "  - Dynamic Mode Switching"
echo "  - Smart Notification"
echo "  - Auto Switch Gaming/Streaming/Idle"
echo ""
cat "$CHANGELOG"
} > temp_changelog.log
mv temp_changelog.log "$CHANGELOG"

# 4️⃣ Set permissions
[ -d "$MODULE_DIR/scripts" ] && chmod +x "$MODULE_DIR/scripts/"*.sh
chmod +x "$MODULE_DIR/post-fs-data.sh"

# 5️⃣ Buat ZIP modul
echo "Mencoba membuat ZIP..."
if command -v zip &> /dev/null; then
    zip -r "../$ZIP_NAME" * -x "*.DS_Store"
elif [ -f "/c/Program Files/7-Zip/7z.exe" ]; then
    "/c/Program Files/7-Zip/7z.exe" a "../$ZIP_NAME" *
else
    echo "Error: Tidak ditemukan zip command atau 7-Zip CLI!"
    echo "Silakan install zip tool untuk Git Bash atau 7-Zip."
    exit 1
fi

echo "=============================="
echo "ZIP berhasil dibuat: ../$ZIP_NAME"
echo "Silakan flash via Magisk Manager"
echo "=============================="
