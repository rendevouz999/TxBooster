#!/bin/bash
# TxBooster_INT v0.0.3
# All-in-one Builder Windows / Git Bash friendly
# Author: rendevouz999
# Repo: https://github.com/rendevouz999

MODULE_DIR="$(pwd)"
ZIP_NAME="TxBooster_INT_v0.0.3.zip"
CHANGELOG="change.log"

echo "=============================="
echo "TxBooster_INT Builder (Git Bash/Windows)"
echo "Folder root modul: $MODULE_DIR"
echo "=============================="

# 1️⃣ Pastikan change.log ada
if [ ! -f "$CHANGELOG" ]; then
    echo "change.log tidak ditemukan, membuat baru..."
    touch "$CHANGELOG"
fi

# 2️⃣ Pastikan post-fs-data.sh ada
if [ ! -f "$MODULE_DIR/post-fs-data.sh" ]; then
    echo "post-fs-data.sh tidak ditemukan, buat file placeholder..."
    echo "#!/system/bin/sh" > "$MODULE_DIR/post-fs-data.sh"
    echo "# placeholder post-fs-data.sh" >> "$MODULE_DIR/post-fs-data.sh"
fi

# 3️⃣ Update change.log versi terbaru
DATE=$(date '+%Y-%m-%d')
echo "## [v0.0.3] – $DATE" > temp_changelog.log
echo "- Core tweak + self-learning engine dengan baseline V0.0.1" >> temp_changelog.log
echo "- Profiling jitter & delay (before/after tweak)" >> temp_changelog.log
echo "- Log management (auto-delete >3 hari)" >> temp_changelog.log
echo "- post-fs-d
