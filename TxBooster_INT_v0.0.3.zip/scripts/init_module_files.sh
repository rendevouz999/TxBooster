#!/bin/bash
# TxBooster_INT v0.0.3
# Generate module.prop, system.prop, change.log
# Author: rendevouz999
# Repo: https://github.com/rendevouz999

MODULE_DIR="$(pwd)"

echo "=============================="
echo "Generating module files..."
echo "Folder root: $MODULE_DIR"
echo "=============================="

# 1️⃣ module.prop
MODULE_PROP="$MODULE_DIR/module.prop"
cat > "$MODULE_PROP" <<EOL
id=txbooster_int
name=TxBooster_INT
version=0.0.3
versionCode=3
author=rendevouz999
description=Modul Magisk untuk optimasi txqueuelen, MTU, self-learning network, dan KsuWebUI
EOL

echo "module.prop created."

# 2️⃣ system.prop (opsional, kosong atau default)
SYSTEM_PROP="$MODULE_DIR/system.prop"
if [ ! -f "$SYSTEM_PROP" ]; then
    cat > "$SYSTEM_PROP" <<EOL
# System properties tambahan untuk TxBooster_INT
# Contoh: default MTU, buffer size
txbooster.default_mtu=1500
txbooster.default_txqueuelen=1000
EOL
    echo "system.prop created."
else
    echo "system.prop already exists, skipped."
fi

# 3️⃣ change.log (buat kosong jika belum ada)
CHANGELOG="$MODULE_DIR/change.log"
if [ ! -f "$CHANGELOG" ]; then
    touch "$CHANGELOG"
    echo "change.log created (empty)."
else
    echo "change.log already exists, skipped."
fi

echo "=============================="
echo "Module files initialization complete."
echo "=============================="
