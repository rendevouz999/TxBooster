[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Magisk Module](https://img.shields.io/badge/Magisk-Compatible-brightgreen.svg)](https://github.com/rendevouz999/TxBooster/releases)
[![Version](https://img.shields.io/badge/version-v0.0.5-blue.svg)](https://github.com/rendevouz999/TxBooster/releases)

# TxBooster_INT — Hybrid AI (v0.0.5)

**Author:** Jxey  
**Email:** joefreccejunior50@gmail.com  
**GitHub:** https://github.com/rendevouz999/TxBooster  
**Version:** v0.0.5 (Hybrid-Sync)  
**License:** MIT License  
**Encryption Seed (public hash):** #3f9a1e6b

---

## Overview

TxBooster_INT v0.0.5 is a hybrid adaptive performance module for Android. It supports both **root (Magisk module)** and **non-root (Shelter Server / Termux)** deployments and introduces:

- AI Policy log relevance scoring and cleanup
- Local self-heal database (`self_heal.db`)
- Server-sync client (`core/ai_sync.sh`) and Shelter Server prototype receiver (v0.0.6)
- Auto-update checker for Magisk module via GitHub releases

This repository release is intended to become the **main** branch for TxBooster_INT development.

---

## Quick Start

### Rooted device (Magisk)
1. Build the module zip with `builder.sh` or use release zip.
2. Install via Magisk Manager → Modules → Install from storage.
3. Reboot device.
4. Logs: `/data/adb/txbooster/logs/core.log` and `/data/adb/txbooster/logs/manager.log`
5. Configure sync in `/data/adb/txbooster/config/server.conf` to point to your Shelter Server.

### Non-root device (Termux / Shelter Server)
1. Copy `shelter_server_v0.0.6/` contents to Termux home.
2. Install dependencies: `pkg install python sqlite curl` and `pip install flask`.
3. Start shelter receiver: `python3 txcloud_sync.py`
4. Logs and DB in working dir: `self_heal.db`, `logs/`

---

## Files of Interest
- `module.prop` — module metadata
- `update.json` — auto-update metadata for Magisk Manager
- `builder.sh` — build and package helper (adds signature + checksum)
- `core/` — scripts for core engine, AI sync, log manager, auto-update
- `shelter_server_v0.0.6/` — server sync prototype and API docs
- `docs/` — roadmap, structure, changelog, license

[BEGIN-TXB-HYBRID-SIGNATURE]
QXV0aG9yOiBKeGV5IHwgU2lnbmVkIFdpdGggRW5jcnlwdGlvbiBTZWVkICgzZjlhMWU2YikK[ENCRYPTED]
[END-TXB-HYBRID-SIGNATURE]

