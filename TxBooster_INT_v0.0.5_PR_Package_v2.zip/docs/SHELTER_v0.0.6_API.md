# SHELTER v0.0.6 API (Draft)

**Author:** Jxey  
**Contact:** joefreccejunior50@gmail.com

See `/api/v1/sync` and `/api/v1/recommendations` endpoints in the shelter prototype.

Security: bearer tokens now, mTLS planned in v0.0.7.

[BEGIN-TXB-HYBRID-SIGNATURE]
QXV0aG9yOiBKeGV5IHwgU2lnbmVkIFdpdGggRW5jcnlwdGlvbiBTZWVkICgzZjlhMWU2YikK[ENCRYPTED]
[END-TXB-HYBRID-SIGNATURE]

