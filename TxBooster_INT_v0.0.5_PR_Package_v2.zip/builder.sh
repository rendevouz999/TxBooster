#!/bin/bash
# Builder helper - will create ZIP and checksum for release
# Author: Jxey
# Email: joefreccejunior50@gmail.com

MODULE_DIR="TxBooster_INT_v0.0.5"
OUT_DIR="out"
BUILD_NAME="TxBooster_INT_v0.0.5.zip"

mkdir -p "$OUT_DIR"
cd "$MODULE_DIR" || exit
zip -r "../$OUT_DIR/$BUILD_NAME" . > /dev/null
cd ..
sha256sum "$OUT_DIR/$BUILD_NAME" > "$OUT_DIR/$BUILD_NAME.sha256"
echo "Built $OUT_DIR/$BUILD_NAME"
