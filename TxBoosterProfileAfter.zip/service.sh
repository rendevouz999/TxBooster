﻿#!/system/bin/sh
# Jalankan profiling_after.sh di background saat boot selesai

/data/adb/modules/txboosterprofileafter/profiling_after.sh &
