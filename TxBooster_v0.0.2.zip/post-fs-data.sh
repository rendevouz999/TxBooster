﻿#!/system/bin/sh
# post-fs-data.sh untuk TxBooster modul Magisk
# Menjalankan service saat boot

/data/adb/modules/txbooster/service.sh &
