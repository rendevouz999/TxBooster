﻿#!/system/bin/sh
# TxBooster & MTU Optimizer v0.0.2
# https://github.com/rendevouz999/TxBooster
# Feedback/Request: joefreccejunior50@gmail.com

LOGFILE="/data/adb/modules/txbooster/txbooster.log"
MODULE_PATH="/data/adb/modules/txbooster"

echo "[TxBooster] Starting service..." > "$LOGFILE"

IFACE="wlan0"
if ! ip link show $IFACE > /dev/null 2>&1; then
  IFACE="rmnet_data0"
fi

VALUES="100000 50000 20000 10000 4000"
for v in $VALUES; do
  if ifconfig $IFACE txqueuelen $v 2>/dev/null; then
    echo "[OK] Applied txqueuelen=$v on $IFACE" >> "$LOGFILE"
    break
  else
    echo "[Fail] Could not apply txqueuelen=$v on $IFACE" >> "$LOGFILE"
  fi
done

CURRENT_MTU=$(ip link show $IFACE | grep mtu | awk '{print $5}')
if [ "$CURRENT_MTU" -gt 1400 ]; then
  ip link set dev $IFACE mtu 1400
  echo "[MTU] Changed MTU from $CURRENT_MTU to 1400 on $IFACE" >> "$LOGFILE"
else
  echo "[MTU] MTU is $CURRENT_MTU on $IFACE, no change needed" >> "$LOGFILE"
fi

if [ -d "/data/adb/modules_update" ]; then
  cmd notification post TxBooster 'MTU & txqueuelen optimized'
elif [ -d "/data/adb/modules" ]; then
  cmd notification post TxBooster 'MTU & txqueuelen optimized'
fi

exit 0
