#!/system/bin/sh
# =========================================
# 🌐 TxBooster_INT Server Sync
# Version: v0.0.5 Hybrid Cloud
# Author : Jxey
# Email  : joefreccejunior50@gmail.com
# =========================================

DB_PATH="/data/adb/txbooster/data/self_heal.db"
SERVER_CONF="/data/adb/txbooster/config/server.conf"
TMP_JSON="/data/adb/txbooster/logs/sync_payload.json"
LOG="/data/adb/txbooster/logs/sync.log"

[ -f "$SERVER_CONF" ] || { echo "[ai_sync] server.conf not found"; exit 1; }

API_URL=$(grep "^SERVER_URL=" "$SERVER_CONF" | cut -d'=' -f2-)
DEVICE_ID=$(grep "^DEVICE_ID=" "$SERVER_CONF" | cut -d'=' -f2-)
API_KEY=$(grep "^API_KEY=" "$SERVER_CONF" | cut -d'=' -f2-)

# Build JSON payload from SQLite
sqlite3 "$DB_PATH" <<EOF > "$TMP_JSON"
.mode json
.output $TMP_JSON
SELECT json_object(
  'device_id', '$DEVICE_ID',
  'timestamp', datetime('now'),
  'logs', json_group_array(json_object(
      'log_name', log_name,
      'relevance_score', relevance_score
  ))
) FROM log_relevance;
EOF

if [ ! -s "$TMP_JSON" ]; then
  echo "[$(date)] [ai_sync] No data to sync" >> "$LOG"
  exit 0
fi

echo "[$(date)] [ai_sync] Sending payload to $API_URL/sync" >> "$LOG"
curl -s -X POST -H "Content-Type: application/json" -H "Authorization: Bearer $API_KEY" -d @"$TMP_JSON" "$API_URL/sync" >> "$LOG" 2>&1
echo "[$(date)] [ai_sync] Done" >> "$LOG"
