#!/system/bin/sh
# ========================================
# 🧩 TxBooster_INT Core Engine
# Version : 0.0.5
# ========================================

LOG_DIR="/data/adb/txbooster/logs"
CORE_PATH="/data/adb/txbooster/core"
mkdir -p "$LOG_DIR" || exit 0

echo "[TxBooster_INT] Initializing Hybrid Core..." >> "$LOG_DIR/core.log"

# 1️⃣ Profiling (learn device state) - placeholder if exists
[ -f "$CORE_PATH/profiling.sh" ] && sh "$CORE_PATH/profiling.sh"

# 2️⃣ Apply baseline tweaks - placeholder
[ -f "$CORE_PATH/auto_selector.sh" ] && sh "$CORE_PATH/auto_selector.sh"

# 3️⃣ Run AI Policy Log Manager
[ -f "$CORE_PATH/log_manager.sh" ] && sh "$CORE_PATH/log_manager.sh" &

# 4️⃣ Run server sync (attempt)
[ -f "$CORE_PATH/ai_sync.sh" ] && sh "$CORE_PATH/ai_sync.sh" &

# 5️⃣ Check updates
[ -f "$CORE_PATH/auto_update.sh" ] && sh "$CORE_PATH/auto_update.sh" &

echo "[TxBooster_INT] Core execution finished." >> "$LOG_DIR/core.log"
