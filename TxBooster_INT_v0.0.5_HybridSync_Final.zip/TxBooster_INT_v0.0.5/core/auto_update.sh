#!/system/bin/sh
# ========================================
# TxBooster_INT Auto Update Checker
# Version : v0.0.5
# Author  : Jxey
# Email   : joefreccejunior50@gmail.com
# ========================================

# Reads config/server.conf for GITHUB_REPO owner/name (or use defaults)
CONF="/data/adb/txbooster/config/server.conf"
LOG="/data/adb/txbooster/logs/auto_update.log"
REPO_OWNER="${REPO_OWNER:-rendevouz999}"
REPO_NAME="${REPO_NAME:-TxBooster}"
GITHUB_API="https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/releases/latest"

mkdir -p "$(dirname "$LOG")"

# Get current installed version from module.prop
MODULE_PROP="/data/adb/txbooster/module.prop"
CURRENT_VERSION=""
[ -f "$MODULE_PROP" ] && CURRENT_VERSION=$(grep '^version=' "$MODULE_PROP" | cut -d'=' -f2)

echo "[$(date)] Auto-update check. Current version: $CURRENT_VERSION" >> "$LOG"

# Query GitHub latest release
RESPONSE=$(curl -s "$GITHUB_API")
LATEST_TAG=$(echo "$RESPONSE" | grep '"tag_name":' | head -n1 | sed -E 's/.*"([^"]+)".*/\1/')
ASSET_URL=$(echo "$RESPONSE" | grep 'browser_download_url' | head -n1 | sed -E 's/.*"([^"]+)".*/\1/')

if [ -z "$LATEST_TAG" ]; then
  echo "[$(date)] No release info found." >> "$LOG"
  exit 0
fi

echo "[$(date)] Latest release: $LATEST_TAG" >> "$LOG"

if [ "$LATEST_TAG" != "$CURRENT_VERSION" ]; then
  echo "[$(date)] New version available: $LATEST_TAG - downloading asset" >> "$LOG"
  mkdir -p /data/adb/txbooster/update
  wget -q -O /data/adb/txbooster/update/update.zip "$ASSET_URL" && echo "[$(date)] Downloaded update.zip" >> "$LOG"
  # Optional: verify signature here (not implemented)
  # Stage update: place update.zip for manual install or auto-install via Magisk (risky)
else
  echo "[$(date)] Already up-to-date." >> "$LOG"
fi
