#!/system/bin/sh
# ========================================
# TxBooster_INT Log Manager (AI Policy Mode)
# Version : v0.0.5-AI
# Author  : Jxey
# Email   : joefreccejunior50@gmail.com
# ========================================

LOG_DIR="/data/adb/txbooster/logs"
DB_PATH="/data/adb/txbooster/data/self_heal.db"
THRESHOLD=0.35

mkdir -p "$LOG_DIR" || exit 0
mkdir -p "$(dirname "$DB_PATH")" || exit 0

sqlite3 "$DB_PATH" "CREATE TABLE IF NOT EXISTS log_relevance (log_name TEXT PRIMARY KEY, last_used DATETIME, relevance_score FLOAT, size_kb INTEGER, last_action TEXT);"

for FILE in $(find "$LOG_DIR" -type f -name "*.log"); do
  SIZE=$(du -k "$FILE" | awk '{print $1}')
  SCORE=$(sqlite3 "$DB_PATH" "SELECT relevance_score FROM log_relevance WHERE log_name='$FILE';")
  [ -z "$SCORE" ] && SCORE=0.0

  if [ "$(date -r "$FILE" +%s)" -lt "$(date -d '3 days ago' +%s)" ]; then
    if (( $(echo "$SCORE < $THRESHOLD" | bc -l) )); then
      rm -f "$FILE"
      sqlite3 "$DB_PATH" "REPLACE INTO log_relevance VALUES('$FILE', datetime('now'), $SCORE, $SIZE, 'deleted');"
      echo "[$(date)] 🧹 Deleted low-score log: $FILE ($SCORE)" >> "$LOG_DIR/manager.log"
    else
      sqlite3 "$DB_PATH" "REPLACE INTO log_relevance VALUES('$FILE', datetime('now'), $SCORE, $SIZE, 'kept');"
      echo "[$(date)] ✅ Kept important log: $FILE ($SCORE)" >> "$LOG_DIR/manager.log"
    fi
  fi
done
