# Shelter Server v0.0.6 - API & Structure (Draft)

**Author:** Jxey
**Contact:** joefreccejunior50@gmail.com
**Date:** 2025-10-07

## Overview
Shelter Server v0.0.6 will formalize the API to support federated aggregation, reputation weighting and secure sync for TxBooster_INT devices.

## API Endpoints (v1)
- `POST /api/v1/sync` : receive device sync payload (log relevance)
  - payload: { device_id, timestamp, logs: [{log_name, relevance_score}] }
  - auth: Bearer API_KEY
- `GET /api/v1/recommendations?limit=20` : return top recommended logs/tweaks
- `POST /api/v1/publish_model` : admin endpoint to publish aggregated model (signed)
- `POST /api/v1/submit_knowledge` : receive knowledge entries (error signature + solution)

## Security
- All endpoints require bearer token; move to mTLS in v0.0.7
- Payloads must be signed by device private key (ed25519) — server verifies signature.

## Data Flow
1. Device posts its log relevance aggregation to `/sync`.
2. Server stores/merges data in `self_heal.db`.
3. Admin or automated federated worker aggregates and publishes new model via `/publish_model`.
4. Devices poll `/recommendations` periodically to update local policy.

## Storage
- `self_heal.db` holds log_relevance and knowledge tables.
- Archive older entries to disk (compressed) every 30 days.

## Notes
This document is draft for v0.0.6 and should be merged into Shelter Server repo/docs.
