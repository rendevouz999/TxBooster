#!/usr/bin/env python3
# txcloud_sync.py - Shelter Server receiver prototype (v0.0.6 structure)
from flask import Flask, request, jsonify
import sqlite3, os

app = Flask(__name__)
DB_PATH = os.path.join(os.getcwd(), 'self_heal.db')

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute('''CREATE TABLE IF NOT EXISTS log_relevance (
        log_name TEXT PRIMARY KEY,
        last_used TEXT,
        relevance_score REAL,
        size_kb INTEGER,
        last_action TEXT
    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS knowledge (
        signature TEXT PRIMARY KEY,
        cause TEXT,
        solution TEXT,
        confidence REAL,
        learned_from TEXT,
        timestamp TEXT
    )''')
    conn.commit()
    conn.close()

@app.route('/api/v1/sync', methods=['POST'])
def sync_data():
    data = request.get_json()
    device_id = data.get('device_id')
    logs = data.get('logs', [])
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    for entry in logs:
        try:
            cur.execute("""REPLACE INTO log_relevance (log_name, last_used, relevance_score, size_kb, last_action)
                        VALUES (?, datetime('now'), ?, 0, 'synced')""", (entry.get('log_name'), entry.get('relevance_score', 0.0)))
        except Exception as e:
            print('DB error', e)
    conn.commit()
    conn.close()
    print(f"[SYNC] Received {len(logs)} entries from {device_id}")
    return jsonify({'status':'ok','received': len(logs)}), 200

@app.route('/api/v1/recommendations', methods=['GET'])
def recommendations():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT log_name, relevance_score FROM log_relevance ORDER BY relevance_score DESC LIMIT 20")
    rows = cur.fetchall()
    conn.close()
    return jsonify({'recommendations':[{'log_name': r[0], 'score': r[1]} for r in rows]})

@app.route('/api/v1/submit_knowledge', methods=['POST'])
def submit_knowledge():
    data = request.get_json()
    signature = data.get('signature')
    cause = data.get('cause')
    solution = data.get('solution')
    confidence = float(data.get('confidence',0.0))
    learned_from = data.get('learned_from','device')
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute("REPLACE INTO knowledge (signature, cause, solution, confidence, learned_from, timestamp) VALUES (?, ?, ?, ?, ?, datetime('now'))", (signature, cause, solution, confidence, learned_from))
        conn.commit()
    except Exception as e:
        print('DB error', e)
    conn.close()
    return jsonify({'status':'ok'}), 200

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5050)
