﻿#!/system/bin/sh
# post-fs-data.sh untuk TxBoosterProfileBefore
# Menjalankan service.d script saat boot

/data/adb/modules/txboosterprofilebefore/service.d/before.sh &
