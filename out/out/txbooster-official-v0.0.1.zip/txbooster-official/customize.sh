#!/system/bin/sh
# Customize install step
ui_print "*******************************"
ui_print " TxBooster Magisk Module "
ui_print "*******************************"
