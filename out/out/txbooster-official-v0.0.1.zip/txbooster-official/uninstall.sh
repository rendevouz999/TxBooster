#!/system/bin/sh
# Cleanup if needed
echo "[TxBooster] Module removed."
