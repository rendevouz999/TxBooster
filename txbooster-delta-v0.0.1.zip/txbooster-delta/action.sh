#!/system/bin/sh
# TxBooster ACTION script

IFACE="wlan0"
VALUES="100000 50000 20000 10000 4000"
LOGFILE="/data/adb/modules/txbooster/txq-action.log"

echo "[TxBooster] Running via ACTION button..." > "$LOGFILE"

for v in $VALUES; do
  if ifconfig $IFACE txqueuelen $v 2>/dev/null; then
    echo "[OK] Applied txqueuelen=$v" >> "$LOGFILE"
    exit 0
  else
    echo "[Fail] $v" >> "$LOGFILE"
  fi
done
