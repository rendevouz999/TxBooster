#!/system/bin/sh
# TxBooster service script
# Apply txqueuelen tweak automatically

IFACE="wlan0"
VALUES="100000 50000 20000 10000 4000"
LOGFILE="/data/adb/modules/txbooster/txq-set.log"

echo "[TxBooster] Starting service..." > "$LOGFILE"

for v in $VALUES; do
  if ifconfig $IFACE txqueuelen $v 2>/dev/null; then
    echo "[OK] Applied txqueuelen=$v" >> "$LOGFILE"
    exit 0
  else
    echo "[Fail] $v" >> "$LOGFILE"
  fi
done
